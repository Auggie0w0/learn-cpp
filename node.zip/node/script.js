const emojis = require('emojis-list');
console.log(emojis[0]);